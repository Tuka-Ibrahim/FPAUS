<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDoctorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('sqlsrv2')->create('UpdatedDoctors', function (Blueprint $table) {
            $table->integer('DrID');
            $table->string('DrName');
            $table->string('Gender');
            $table->string('email');
            $table->integer('BirthYear');
            $table->string('MasterDegree');
            $table->integer('GraduationYear');
            $table->string('old');
            $table->string('password');
            $table->text('Description');
            $table->integer('Department');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('doctors');
    }
}
