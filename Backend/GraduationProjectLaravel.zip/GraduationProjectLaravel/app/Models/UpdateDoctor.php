<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UpdateDoctor extends Model
{
    use HasFactory;
    protected $connection = 'sqlsrv2';
    protected $table='doctors';
    protected $fillable = [
        'DrName', 'email', 'password', 'Gender', 'GraduationYear', 'BirthYear'
        , 'MasterDegree', 'Description', 'Department'
    ];
}
