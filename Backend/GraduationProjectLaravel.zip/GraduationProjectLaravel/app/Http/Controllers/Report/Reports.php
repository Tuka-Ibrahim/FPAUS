<?php

namespace App\Http\Controllers\Report;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Reports extends Controller
{

    public function QaReport()
    {

        $data = \DB::select('select
       students.FullName,studentfacttable.FinalWork,courses.CourseName,time.Year
       from studentfacttable,students,time,courses,exams
       where
             studentfacttable.StudentID=students.StudentID and
             studentfacttable.CourseID=courses.CID and
             studentfacttable.examID=exams.examID and
             studentfacttable.TimeID=time.TimeID and
             studentfacttable.CourseSuccess=0;');

        return response()->json([
            'status' => 200,
            'Students' => $data,

            //'DataBase'=>DB::connection('sqlsrv2')->getDatabaseName(),
        ]);
    }

    public function DeanReport()
    {

        $data = \DB::select('select
       doctors.DrName,courses.CourseName,time.Year,AVG(studentfacttable.FinalWork+studentfacttable.YearWork) as AverageOfGrades
       from studentfacttable,courses,doctors,time
       where
             studentfacttable.DoctorID=doctors.DrID and
             studentfacttable.CourseID=courses.CID and
             studentfacttable.TimeID=time.TimeID
       group by doctors.DrName,courses.CourseName,time.Year ;');


        return response()->json([
            'status' => 200,
            'Doctors' => $data,
        ]);
    }


}

//            ->table(DB::raw('studentfacttable','courses','doctors','time'))->
//       selectRaw('doctors.DrName,courses.CourseName,time.Year,AVG(studentfacttable.FinalWork) as AverageOfGrades')
//            ->where([
//                    ['studentfacttable.DoctorID','=','doctors.DrID'],
//                    ['studentfacttable.CourseID','=','courses.CID'],
//                    ['studentfacttable.TimeID','=','time.TimeID']
//                ]
// )->groupBy('doctors.DrName','courses.CourseName','time.Year')->get();
//$data=DB::connection('sqlsrv2')->table('Exam')
////            FinalWork,,Exam.StudentID
////                subject elly eldoctor edaha bl sana elly edaha feeha w average of grades
//    ->selectRaw('Exam.CID,doctorcourse.DrID,doctors.DrName,Course.CourseName,
//            YEAR(doctorcourse.CourseTime) as Year ,FinalWork')
//    ->join('doctorcourse',function ($join) {
//        $join->on('Exam.CID', '=', 'doctorcourse.CID');
//    }
//    )
//    ->join('doctors',function ($join) {
//        $join->on('doctors.DrID', '=', 'doctorcourse.DrID');
//    }
//    )->join('Course',function ($join) {
//        $join->on('Exam.CID', '=', 'course.CID');
//    })
//
////            ->avg('FinalWork')
//    ->where('Exam.FinalWork','>=',50)->distinct('Year')
//    ->get();
//        $grades=DB::connection('sqlsrv2')->table('Exam')->selectRaw('Exam.FinalWork,Exam.CID')->get();
//        $data=DB::connection('sqlsrv2')->table('doctorcourse')
////            FinalWork,,Exam.StudentID
////                subject elly eldoctor edaha bl sana elly edaha feeha w average of grades
//            ->selectRaw('doctorcourse.CID,doctorcourse.DrID,doctors.DrName,Course.CourseName,
//            YEAR(doctorcourse.CourseTime) as Year ')
////            ,Exam.FinalWork
////            ->join('doctorcourse',function ($join) {
////                $join->on('Exam.CID', '=', 'doctorcourse.CID');
////            }
////            )
//            ->join('doctors',function ($join) {
//                $join->on('doctors.DrID', '=', 'doctorcourse.DrID');
//            }
//            )->join('Course',function ($join) {
//                $join->on('doctorcourse.CID', '=', 'course.CID');
//            })
////            ->join('Exam',function ($join) {
////                $join->on('Exam.CID', '=', 'doctorcourse.CID');
////            }
////            )
//
////            ->avg('FinalWork')
////            ->where('Exam.FinalWork','>=',50)->distinct('Year')
//            ->get();
////
