<?php

namespace App\Http\Controllers\Report;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Reports extends Controller
{

    public function QaReport()
    {

        $data = \DB::select('select
       students.FullName,studentfacttables.FinalWork,courses.CourseName,time.Year
       from studentfacttables,students,time,courses,exams
       where
             studentfacttables.StudentID=students.StudentID and
             studentfacttables.CourseID=courses.CID and
             studentfacttables.examID=exams.examID and
             studentfacttables.TimeID=time.TimeID and
             studentfacttables.CourseSuccess=0;');

        return response()->json([
            'status' => 200,
            'Students' => $data,
        ]);
    }

    public function DeanReport()
    {

        $data = \DB::select('select
       doctors.DrName,courses.CourseName,time.Year,AVG(studentfacttables.FinalWork+studentfacttables.YearWork) as AverageOfGrades
       from studentfacttables,courses,doctors,time
       where
             studentfacttables.DoctorID=doctors.DrID and
             studentfacttables.CourseID=courses.CID and
             studentfacttables.TimeID=time.TimeID
       group by doctors.DrName,courses.CourseName,time.Year ;');


        return response()->json([
            'status' => 200,
            'Doctors' => $data,
        ]);
    }


}








//            ->table(DB::raw('studentfacttable','courses','doctors','time'))->
//       selectRaw('doctors.DrName,courses.CourseName,time.Year,AVG(studentfacttable.FinalWork) as AverageOfGrades')
//            ->where([
//                    ['studentfacttable.DoctorID','=','doctors.DrID'],
//                    ['studentfacttable.CourseID','=','courses.CID'],
//                    ['studentfacttable.TimeID','=','time.TimeID']
//                ]
// )->groupBy('doctors.DrName','courses.CourseName','time.Year')->get();
//$data=DB::connection('sqlsrv2')->table('Exam')
////            FinalWork,,Exam.StudentID
////                subject elly eldoctor edaha bl sana elly edaha feeha w average of grades
//    ->selectRaw('Exam.CID,doctorcourse.DrID,doctors.DrName,Course.CourseName,
//            YEAR(doctorcourse.CourseTime) as Year ,FinalWork')
//    ->join('doctorcourse',function ($join) {
//        $join->on('Exam.CID', '=', 'doctorcourse.CID');
//    }
//    )
//    ->join('doctors',function ($join) {
//        $join->on('doctors.DrID', '=', 'doctorcourse.DrID');
//    }
//    )->join('Course',function ($join) {
//        $join->on('Exam.CID', '=', 'course.CID');
//    })
//
////            ->avg('FinalWork')
//    ->where('Exam.FinalWork','>=',50)->distinct('Year')
//    ->get();
//        $grades=DB::connection('sqlsrv2')->table('Exam')->selectRaw('Exam.FinalWork,Exam.CID')->get();
//        $data=DB::connection('sqlsrv2')->table('doctorcourse')
////            FinalWork,,Exam.StudentID
////                subject elly eldoctor edaha bl sana elly edaha feeha w average of grades
//            ->selectRaw('doctorcourse.CID,doctorcourse.DrID,doctors.DrName,Course.CourseName,
//            YEAR(doctorcourse.CourseTime) as Year ')
////            ,Exam.FinalWork
////            ->join('doctorcourse',function ($join) {
////                $join->on('Exam.CID', '=', 'doctorcourse.CID');
////            }
////            )
//            ->join('doctors',function ($join) {
//                $join->on('doctors.DrID', '=', 'doctorcourse.DrID');
//            }
//            )->join('Course',function ($join) {
//                $join->on('doctorcourse.CID', '=', 'course.CID');
//            })
////            ->join('Exam',function ($join) {
////                $join->on('Exam.CID', '=', 'doctorcourse.CID');
////            }
////            )
//
////            ->avg('FinalWork')
////            ->where('Exam.FinalWork','>=',50)->distinct('Year')
//            ->get();
////
