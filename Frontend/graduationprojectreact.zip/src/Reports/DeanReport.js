import React, {Component} from "react";
import axios from "axios";
import Table from 'react-bootstrap/Table'

export default class Deanreport extends Component {
    state = {
        Doctors: [], loading: true
    }

    async componentDidMount() {
        const res = await axios.get('http://127.0.0.1:8000/api/Reports/DeanReport');
        // console.log(res);
        if (res.status === 200) {
            this.setState({
                Doctors: res.data.Doctors, loading: false
            });

        }
    }

    render(){

        if (this.state.loading) {
            return <h4>Loading Doctors Data...</h4>
        }
        return (
            // <h1>Hello</h1>
            <div className="container3">
                <Table striped bordered hover responsive="sm">
                    <thead>
                    <tr style={{
                        backgroundColor: '#7A83DF'}}>
                        <th>Course Name</th>
                        <th>Doctor Name</th>
                        <th>Year</th>
                        <th>Average Of Grades</th>

                    </tr>
                    </thead>
                    <tbody>

                    {
                        this.state.Doctors.map((item) =>
                            <>
                                <tr>
                                    <td> {item.CourseName}</td>
                                    <td>{item.DrName}</td>
                                    <td>{item.Year}</td>
                                    <td>{item.AverageOfGrades}</td>
                                </tr>
                            </>
                        )

                    }
                    </tbody>
                </Table>
            </div>

        );
    }
}