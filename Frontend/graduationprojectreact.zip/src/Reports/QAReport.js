import React, {Component} from "react";
import axios from "axios";
import Table from 'react-bootstrap/Table'

export default class QAreport extends Component {
    state = {
        Students: [],
        loading: true

    }
    async componentDidMount() {
        const res = await axios.get('http://127.0.0.1:8000/api/Reports/QaReport');
        //console.log(res);
        if (res.status === 200) {
            this.setState({
                Students: res.data.Students,
                loading: false
            });

        }
    }
    render() {
        if (this.state.loading) {
            return <h4>Loading QA Report Data...</h4>
        }
        return (
            <div className="container4">
                <Table striped bordered hover responsive="sm">
                    <thead>
                    <tr  style={{
                            backgroundColor: '#7A83DF'}}>
                        <th>FUll Name</th>
                        <th>Failed Course</th>
                        <th>Year</th>
                        <th>Hours</th>
                    </tr>
                    </thead>
                    <tbody>

                    {
                        this.state.Students.map((item) =>
                            <>
                                <tr>
                                    <td> {item.FullName}</td>
                                    <td>{item.CourseName}</td>
                                    <td>{item.Year}</td>
                                    <td>{item.Year}</td>
                                </tr>
                            </>
                        )

                    }
                    </tbody>
                </Table>
            </div>
        );
    }
}