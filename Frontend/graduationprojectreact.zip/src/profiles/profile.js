import React,{Component} from "react";
import axios from "axios";

// ,{useState,useEffect}
export default class Profile extends Component {
// function Profile(){
  state={
    Doctor:[],
    loading:true

  }
  async componentDidMount(){
    const res=await axios.get('http://127.0.0.1:8000/api/showProfile');
    console.log(res);
    if(res.status === 200)
            {
              this.setState({
                Doctor:res.data.Doctor,
                loading:false
              });
            
            }
    }
  render(){
  //   const [data, setData] = useState([]);
  //   useEffect(() => {
  //   async function fetch() {
  //     const response = await fetch('http://127.0.0.1:8000/showProfile');
  //     const json = await response.json();
  //     setData(json);
  //   }
  //   fetch(); 
  // },[]);
  // const [loading, setLoading] = useState(true);
  //   const [students, setStudents] = useState([]);
    // useEffect(() => {
    //     // axios.get(`showProfile`).then(res=>{
    //     //     if(res.status === 200)
    //     //     {
    //     //         setStudents(res.data.students)
    //     //         setLoading(false);
    //     //     }
    //     // });
    // }, []);
    // console.warn("result",data)
//     useEffect(async ()=>{
//       let result= await fetch("http://127.0.0.1:8000/showProfile",{
//         mode: 'no-cors'})
//       let response= await result.json();
//       setData(response);
//     },[])
// console.warn("result",data)
// const [data, fetchUsers] = useState([])
//   const getData = () => {
//     fetch('http://127.0.0.1:8000/showProfile')
//       .then((res) => res.json())
//       .then((res) => {
//         console.log(res)
//         fetchUsers(res)
//       })
//   }
//   useEffect(() => {
//     getData()
//   }, [])
if(this.state.loading)
{
    return <h4>Loading Doctor Data...</h4>
}


    return (
      <div className="container2">
        {/* user & cover profile */}
        <div>
          <img className="user_profile"  src='/images/doctor.jpg'alt='User Profile'/>
          {
          this.state.Doctor.map( (item) => 
            
              <><h4 className="user_name">{item.DrName}</h4>
              <h6 className="user_role">{item.MasterDegree}</h6></> 
          )
          }
        
        </div>
        <div>
          <img id="cover_profile" src="images/cover2.jpg" className='img-fluid shadow-4 mt-1' alt='The cover of profile'/>
        </div>

        <button type="button" className="btn btn-primary mt-4 d-flex ms-auto">Edit</button>
        <div className="row mb-5 mt-5 shadow p-3 mb-5 bg-body rounded">
          <div className="col-sm-12 ">
            <div className="aboutProfile">
              <div className="aboutProfile-content bg-white p-3">
                <div className="row">
                  <div className="col-md-6">
                    <div className="title mb-4">
                      <h5>About Me</h5>
                    </div>
                    <div className="aboutData">


                      <div className="mb-3">
                        <span className="name bgText">Full Name</span>
                        <p className="pt-3 text-primary">{
                        this.state.Doctor.map( (item) =>
                        <>{item.DrName}</>
                        )}

                        </p>

                        <div className="about-underline border-primary border-bottom">

                        </div>
                      </div>
                      <div className="mb-3">
                        <span className="department bgText">Department</span>
                        <p className="pt-3 text-primary">
                        {/*  {*/}
                        {/*this.state.Doctor.map( (item) =>*/}
                        {/*<>{item.Department}</>*/}
                        {/*)}*/}
                         Information System
                        </p>
                        <div className="about-underline border-primary border-bottom"></div>
                      </div>
                      <div className="mb-3">
                        <span className="gender bgText">Gender</span>
                        <p className="pt-3 text-primary">{
                        this.state.Doctor.map( (item) =>
                        <>{item.Gender}</>
                        )}
                        </p>
                        <div className="about-underline border-primary border-bottom"></div>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-6 pt-5">
                    <div className="more">
                      <div className="aboutData">
                        <div className="mb-3">
                          <span className="email bgText">Email</span>
                          <p className="pt-3 text-primary">{
                        this.state.Doctor.map( (item) =>
                        <>{item.email}</>
                        )}
                        </p>
                          <div className="about-underline border-primary border-bottom"></div>
                        </div>
                        <div className="mb-3">
                          <span className="mDegree bgText">Master Degree</span>
                          <p className="pt-3 text-primary">{
                        this.state.Doctor.map( (item) =>
                        <>{item.MasterDegree}</>
                        )}
                        </p>
                          <div className="about-underline border-primary border-bottom"></div>
                        </div>
                        <div className="mb-3">
                          <span className="gpYear bgText">Graduation year</span>
                          <p className="pt-3 text-primary">{
                        this.state.Doctor.map( (item) =>
                        <>{item.GraduationYear}</>
                        )}
                        </p>
                          <div className="about-underline border-primary border-bottom"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Description */}

        <div className="row shadow p-3 mb-5 bg-body rounded">
          <div className="col-sm-12">
            <div className="title mb-4 bgText">
              <h5>Description About Me</h5>
            </div>
            <div className="description">
              <p  id="userDescription" className="text-primary">I am a Professor and Director specialized in image processing
              (My PHD Subject) and has more than 5 years of experience as
              executive board member. Assist in designing image processing
              system architectures and evaluating image processing
              algorithms. Research and development of image processing
              algorithms and realizing the designs on new product programs.</p>

              {/* <label for="floatingTextarea">Comments</label> */}
            </div>
            {/* <div className="aboutData">
            <textarea
              class="text-secondary"
              placeholder=" I am a Professor and Director specialized in image processing
                (My PHD Subject) and has more than 5 years of experience as
                executive board member. Assist in designing image processing
                system architectures and evaluating image processing
                algorithms. Research and development of image processing
                algorithms and realizing the designs on new product programs."
            ></textarea>
          </div> */}
          </div>
        </div>
      </div>
    );
  }
 
}

// export default Profile;
