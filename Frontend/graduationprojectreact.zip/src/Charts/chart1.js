import React, {Component} from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from "recharts";

export default class chart1 extends Component {
    render(){
// function Chart1(){
    const data = [
        {
          name: "GPA 1",
          uv: 180
        },
        {
          name: "GPA 2",
          uv: 602
        },
        {
          name: "GPA 3",
          uv: 420
        },
        {
          name: "GPA 3.5",
          uv: 220
        },
      ];  
    return (
      <div className="chart1">
        <div className="container">
            <div className="column-1">
              <h6><u>Last Year</u></h6>
            </div>
            <div className="column-2">
              <h6><u>Last 2 Years</u></h6>
            </div>
            <div className="column-3">
              <h6><u>Last 3 Years</u></h6>
            </div>
            <div class="dash"></div>
        </div>
        
        <AreaChart
        width={700}
        height={400}
        data={data}
        margin={{
          top: 10,
          right: 30,
          left: 0,
          bottom: 0
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Area type="monotone" dataKey="uv" stroke="#8787FF" fill="#8884d8" />
      </AreaChart>
      </div>
    );
}
}
// export default Chart1;