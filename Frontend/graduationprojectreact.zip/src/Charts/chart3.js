import React, {Component} from "react";
// function Chart3(){
export default class Chart3 extends Component {
    render(){
    return (
       <div className="chart3">
         <div className="container">
           <div className="row">
             <div className="col one">
              <img className="image" src="../images/student.webp" />
             </div>
             <div className="col two">
               <h5><b>1989</b></h5>
               <h5>Students</h5>
             </div>
           </div>
         </div>
         <div className="container">
           <div className="row">
             <div className="col one">
              <img className="image" src="../images/TA.webp" />
             </div>
             <div className="col two">
               <h5><b>450</b></h5>
               <h5>Total Doctors</h5>
             </div>
           </div>
         </div>
         <div className="container">
           <div className="row">
             <div className="col one">
              <img className="image" src="../images/prof.png" />
             </div>
             <div className="col two">
               <h5><b>600</b></h5>
               <h5>Teacher Assistants</h5>
             </div>
           </div>
         </div>
         <div className="container">
           <div className="row">
             <div className="col one">
              <img className="image" src="../images/department.png"/>
             </div>
             <div className="col two">
               <h5><b>5</b></h5>
               <h5>Departments</h5>
             </div>
           </div>
         </div>
       </div>
    );
}}
// export default Chart3;