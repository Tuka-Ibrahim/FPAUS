import React, {Component} from "react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend
  } from "recharts";

export default class Chart4 extends Component {
    render(){
// function Chart4(){
    const data = [
        {
          name: "IS",
          IS: 800
        },
        {
          name: "IT",
          IT: 600
        },
        {
          name: "CS",
          CS: 850
        },
        {
          name: "DS",
          DS: 280
        },
        {
          name: "AI",
          AI: 430
        }
      ];   
    return (
      <div className="chart4">
        <BarChart
        width={400}
        height={300}
        data={data}
        margin={{
        top: 20,
        right: 30,
        left: 20,
        bottom:5 
      }}
    >
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Bar dataKey="IS" stackId="a" fill="#165146" />
      <Bar dataKey="IT" stackId="a" fill="#365068" />
      <Bar dataKey="CS" stackId="a" fill="#622727" />
      <Bar dataKey="DS" stackId="a" fill="#1E174E" />
      <Bar dataKey="AI" stackId="a" fill="#694568" />
    </BarChart>
    </div>
    );
}}
// export default Chart4;