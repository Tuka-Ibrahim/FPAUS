import React, {Component} from "react";
import { PieChart, Pie, Sector, Cell } from "recharts";
export default class chart24Doctor extends Component {
    render(){
        // function Chart2(){
  
    const data1 = [
      { name: "Group A", value: 400 },
    ];
    const data2 = [
      { name: "Group A", value: 400 },
    ];
    const data3 = [
      { name: "Group A", value: 400 },
    ];
    const color1 = ["#20213D"];
    const color2 = ["#859BB0"];
    const color3 = ["#A1D4DB"]; 
    return (
      <div className="chart2">
        <div className="container">
            <div className="column-1">
              <h5>Students Performance</h5>
            </div>
            <div className="column-2">
              <h5>Teacher Assistants Performance</h5>
            </div>
        </div>
    <PieChart width={800} height={400}>
      <Pie
        data={data1}
        cx={120}
        cy={200}
        startAngle={60}
        endAngle={280}
        innerRadius={60}
        outerRadius={80}
        fill="#8884d8"
        paddingAngle={5}
        dataKey="value"
      >
        {data1.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={color1[index % color1.length]} />
        ))}
      </Pie>
      <Pie
        data={data2}
        cx={320}
        cy={200}
        startAngle={15}
        endAngle={280}
        innerRadius={60}
        outerRadius={80}
        fill="#8884d8"
        paddingAngle={5}
        dataKey="value"
      >
        {data2.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={color2[index % color2.length]} />
        ))}
      </Pie>
    </PieChart>
    </div>
    );
}
}
// export default Chart2;
