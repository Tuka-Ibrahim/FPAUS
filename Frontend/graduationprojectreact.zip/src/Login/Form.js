import React, { useState } from 'react';
//import './LoginForm.css';
import './LoginForm.css'
import LoginForm from './LoginForm.js';
import FormSuccess from './FormSuccess.js';
import fpauslogo from "../images/img-2.png";
import {Navigate, Route, Routes} from "react-router-dom";
import { Switch, Redirect } from 'react-router-dom';
import Profile from "../profiles/profile";


const Form = () => {
    const [isSubmitted, setIsSubmitted] = useState(false);

    function submitForm() {
        setIsSubmitted(true);
    }
    return (
        <>
            <div className='form-container'>
                <span className='close-btn'>×</span>
                <div className='form-content-left'>
                    <img className='form-img' src={fpauslogo} alt={"logophoto"} />
                </div>
                {!isSubmitted ? (
                    <LoginForm submitForm={submitForm} />


                ) : (
                    // <FormSuccess/>
                    <Profile/>
                )}
            </div>
        </>
    );
};

export default Form;