import './LoginForm.css'
import React, { useState } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

/* in Profile page :
const {users} = useParams();
    let history = useNavigate();

    const usersss = localStorage.getItem('users');

    const logout = () =>
    {
        localStorage.removeItem("users")
        history.push("/");
    }

/*
    const LoginForm = () => {
      const [email, setEmail] = React.useState('');
      const [password, setPassword] = React.useState('');

      async function login() {
        console.warn(email, password);
        let item = { email, password };
        let result = await fetch("http://localhost:8000/api/login", {
          method: 'POST',
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: JSON.stringify(item)
        });
        result = await result.json();
        localStorage.setItem("users", JSON.stringify(result))
      }


/*function LoginForm (){
  const [loginInput, setLogin] = useState({
    email:'',
    password:'',
  });


  const handleInput = (e) =>{
    e.persist();
    setLogin({...loginInput, [e.target.name]:e.target.value});
  }

  const loginSubmit = (e) =>{
    e.perventDefault();


    const data = {
      email:loginInput.email,
      password:loginInput.password,
    }

    axios.post("http://localhost:8000/api/login",data).then(res => {

    });
  }
*/
//<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
const LoginForm = () => {
    const [setMsg] = useState('');
    /*const [username, setUsername] = useState("");
    const [pass, setPass] = useState("");*/
    const [user, setUser] = useState({
        email: "",
        password: ""
    });
   let history = useNavigate();   //lw content l page e5tfa fa shel de hysht8l
    const { email, password } = user;
    const onInputChange = e => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const signIn = () => {
        if (user.email === '') {
            alert('Email Field is empty')
        }
        else if (user.password === '') {
            alert('Password Field is empty')
        }
        axios.post("http://127.0.0.1:8000/api/login", user).then(response => {
            console.log(response.data);
            setMsg(response.data);
            localStorage.setItem("users", response.data);
            history.push("showProfile"); //hena hn-push eno yru7 ll profile

        });
    }

    return (

        <div className="form-content-right">
            <div className="form">
                <h1>Sign in</h1>
                <div className="form-inputs">
                    <label className="form-label" />
                    <input type="email" name="email" value={email} onChange={e => onInputChange(e)} className='form-input'
                           placeholder='eg:i.ahmed@fci-cu.edu.eg'
                    />
                </div>
                <div className="form-inputs">
                    <label className="form-label" />
                    <input type="password" name="password" value={password} onChange={e => onInputChange(e)} className='form-input'
                           placeholder='********'
                    />
                    <p className="Forgot-pass">
                        <a href={"#"}  name={'forget'}>Forgot password?</a>
                    </p>
                </div>
                <button onClick={signIn} className='form-input-btn' >
                    Sign In
                </button>
            </div>
        </div>
    )
}
export default LoginForm