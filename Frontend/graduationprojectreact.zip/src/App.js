// import React, { Component } from "react";
import React from 'react'
import { Component } from 'react';
import Profile from "./profiles/profile";
import Form from "./Login/Form.js";
import { Route, Routes } from "react-router-dom";
// import { Navigate } from 'react-router-dom';
// import { Switch, Redirect } from 'react-router-dom';
// import {Nav} from "react-bootstrap";

import QAreport from "./Reports/QAReport";
import Deanreport from "./Reports/DeanReport";
import QADashboard from "./Dashboards/QADashboard";
import DoctorDashboard from "./Dashboards/DoctorDashboard";
import EDashboard from "./Dashboards/EDashboard";

class App extends Component {
// export default function App() {
 render(){
  return (
    <div className="container">
        {/*<Routes>*/}
        {/*    <Form/>*/}
        {/*    <Navigate from="/login/:email" to="/showProfile/:email" />*/}
        {/*    <Route path="/showProfile">*/}
        {/*        <Profile/>*/}
        {/*    </Route>*/}
        {/*</Routes>*/}


        <Routes>
            <Route path="/login" element={ <Form/> } />
            <Route path="/showProfile" element={ <Profile/> } />
            <Route path="/Reports/QAReport" element={ <QAreport/> } />
            <Route path="/Reports/DeanReport" element={ <Deanreport/> } />
            <Route path="/Dashboards/QADashboard" element={ <QADashboard/> } />
            <Route path="/Dashboards/DoctorDashboard" element={ <DoctorDashboard/> } />
            <Route path="/Dashboards/ExecutiveDashboard" element={ <EDashboard/> } />
        </Routes>

      {/*  <Form/>*/}
      {/*<Profile/>*/}
     </div>
  );
 }

}

export default App;

// import { Component } from 'react';

// function Test(){
//   return <div>welcome from test</div>;
// }
// class App extends Component{
//   render(){
//     return (
//     <div className="App">
//           Learn React

//      <Test/>
//     </div>
//   );}

// }

// export default App;
