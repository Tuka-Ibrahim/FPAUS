import "../App.css";
import React, {Component} from "react";
import Chart1 from "../Charts/chart1";
import Chart2 from "../Charts/chart24Doctor";

// // class App extends Component {
// export default function App() {
export default class DoctorDashboard extends Component {
// class App extends Component {
// export default function App() {
  render() {
  return (
    <div className="container" >
      <div class="col noMargin">
        <div className="firstCol">
          <h1>Cources</h1>
          <a>Programming1 </a><br></br>
          <a>Object Oriented Programming</a><br></br>
          <a>Data Structure</a><br></br>
          <a>Algorithms</a><br></br>
          <a>Software Engineering</a><br></br>
          <a>Advanced Software Engineering</a><br></br>
          <a>Cloud Computing</a><br></br>
          <a>Semantic Web and ontology</a>
        </div>
      </div>
      <div class="col noMargin">
        <div class="row-one">
          <Chart1/>
        </div>
        <div class="row-two">
          <Chart2/>
        </div>
      </div>
    </div>
  );
}
}


