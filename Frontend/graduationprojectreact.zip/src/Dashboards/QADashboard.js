import "../App.css";
import React, {Component} from "react";
import Chart1 from "../Charts/chart1";
import Chart2 from "../Charts/chart2";
import Chart3 from "../Charts/chart3";
import Chart4 from "../Charts/chart4";

export default class QADashboard extends Component {
// class App extends Component {
// export default function App() {
    render() {
        return (
            <div className="container">
                <div class="row noMargin">
                    <div class="col-one">
                        <Chart1/>
                    </div>
                    <div class="col-two">
                        <Chart2/>
                    </div>
                </div>
                <div class="row noMargin">
                    <div class="col-one">
                        <Chart3/>
                    </div>
                    <div class="col-two">
                        <Chart4/>
                    </div>
                </div>
            </div>
        );
    }
}
