<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Doctor;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
   public function login(Request $req)
    {
        $user= Doctor::where(['email'=>$req->email])->first();
        if(!$user || !Hash::check($req->password,$user->password))
        {
            return "Username or Password is not matched";
        }
        else{
            $req->session()->put('doctor',$user);
            return $user;
        }
    }
}
